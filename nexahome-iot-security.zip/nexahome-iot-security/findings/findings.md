# Achados

Escala qualitativa: impacto e probabilidade baixa/média/alta; risco alto quando a combinação estimada justifica tratamento antes do piloto. As duas linhas são condições do artefato didático ou lacunas de assurance, não vulnerabilidades confirmadas no produto NexaSense.

| ID | Evidência | Fragilidade / ameaça | Impacto | Probabilidade | Risco | Recomendação |
|---|---|---|---|---|---|---|
| F01 | `src/main.cpp` imprime identificador e telemetria na UART do laboratório. Console reproduzível após compilar e iniciar Wokwi; execução não capturada nesta entrega. | Logs excessivos podem expor dados se console/pads permanecerem acessíveis. Ator: pessoa com proximidade física. | Médio (divulgação de dados operacionais) | Média no protótipo didático; desconhecida no produto | Médio, condicional | Reduzir logs em release; mascarar identificadores; controlar pads/debug e verificar configuração de produção. Validar em placa. |
| F02 | Não há firmware de produto, inventário de placas, captura de tráfego nem procedimento de update anexado. | Falta de evidência impede demonstrar controle de acesso, confidencialidade, integridade e recuperação de update. A ameaça é permanecer com controle insuficiente desconhecido. | Alto potencial | Desconhecida | Médio (incerteza de assurance; não é vulnerabilidade confirmada) | Bloquear decisão de piloto até evidências do laboratório autorizado: hash, análise binária, tráfego, interface e teste de update. |

Risco residual: a existência genérica de UART/JTAG/flash não é achado explorável sem confirmação de acesso, proteção e resultado. Nenhum teste destrutivo, acesso privilegiado ou eFuse foi realizado.
