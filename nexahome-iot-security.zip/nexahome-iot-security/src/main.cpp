#include <Arduino.h>
#include <DHT.h>
static constexpr uint8_t DHT_PIN = 15;
static constexpr uint8_t DHT_TYPE = DHT22;
DHT dht(DHT_PIN, DHT_TYPE);
void setup() {
  Serial.begin(115200);
  dht.begin();
  delay(500);
  Serial.println("NexaSense LAB boot v0.1");
  Serial.println("[debug] device_id=LAB-NEXA-01");
  Serial.println("[debug] transport=MQTT (payload example only; no broker)");
  Serial.println("[debug] UART console enabled");
}
void loop() {
  const float humidity = dht.readHumidity();
  const float temperature = dht.readTemperature();
  if (isnan(humidity) || isnan(temperature)) Serial.println("[debug] sensor_read_error");
  else Serial.printf("[telemetry] {\"device_id\":\"LAB-NEXA-01\",\"temperature_c\":%.1f,\"humidity_pct\":%.1f}\n", temperature, humidity);
  delay(3000);
}
