# Análise de comunicações

## Observado no artefato

O firmware de demonstração escreve eventos de console no monitor serial a 115200 baud. Os eventos contêm um identificador de laboratório e, em cada ciclo, temperatura e umidade. Serial é comunicação local pela UART, sem criptografia ou autenticação na própria camada UART. O acesso físico à placa e ao cabeamento é pressuposto.

## Não observado

Não há associação Wi-Fi, endereço de origem/destino IP, MQTT efetivo, HTTP, broker, TLS, autenticação de rede ou tráfego capturado. A linha `transport=MQTT` é uma mensagem fixa e declara payload example only. Não classificar isso como evidência de MQTT inseguro.

## Próxima coleta autorizada

Com placa do laboratório e broker local controlado: registrar captura em rede isolada, mapear DNS/IP/portas e tópicos, inspecionar QoS e payload, verificar autenticação e TLS/certificados, e remover quaisquer segredos antes de anexar PCAP. Comparar tráfego sem e com TLS somente contra o ambiente próprio.
