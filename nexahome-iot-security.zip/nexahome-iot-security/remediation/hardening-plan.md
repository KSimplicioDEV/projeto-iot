# Plano de hardening

## Antes do piloto

1. Fechar inventário de hardware, esquema, revisão de módulo ESP32, sensores, pinout e configuração de boot.
2. Reduzir serial de produção a estado mínimo; retirar identificadores e valores operacionais desnecessários dos logs; garantir que debug fica limitado a builds de laboratório.
3. Não manter credenciais universais; provisionar identidade e segredo únicos por dispositivo, com armazenamento protegido e rotação suportada.
4. Selecionar protocolo e serviço local, exigir autenticação por dispositivo e TLS com validação correta de certificado; limitar tópicos/API e segmentar rede.
5. Implementar update assinado, validação de versão/anti-rollback conforme modelo de ameaça e recuperação segura (A/B ou imagem de fallback); documentar origem, hash e processo de release.
6. Registrar capacidade de inventário, configuração, proteção de dados, controle de acesso à interface, atualização e estado de segurança conforme NISTIR 8259A.

## Produção ESP32 (projeto e validação)

- Avaliar Secure Boot e Flash Encryption em combinação. Secure Boot verifica autenticidade/integridade do firmware; Flash Encryption reduz leitura da flash. São controles complementares, não substitutos de TLS/autenticação. Planejar chaves por dispositivo, provisionamento e recuperação.
- Revisar UART ROM download e JTAG para variante/revisão real. Desabilitar ou restringir interfaces de produção apenas após validar estratégia de serviço e recuperação. Não queimar eFuses irreversíveis durante atividade educacional.
- Fazer análise de dependências, SBOM, assinatura de artefatos e processo de divulgação de vulnerabilidades.
- Repetir avaliação em amostra de produção e documentar exceções, evidência e aceite de risco.

## Prioridade

P0: evidência de protocolo real, credenciais e cadeia de update antes do piloto. P1: redução de debug, controle de interfaces, hardening de flash/boot após planejamento de chaves. P2: processo contínuo de inventário, suporte, monitoramento e divulgação coordenada.

Referências: NISTIR 8259A (identificação, configuração, proteção de dados, acesso lógico, atualização, estado e segurança do dispositivo); ETSI EN 303 645 V3.1.3 (2024-09) (senhas, comunicação, update, vulnerabilidades); MITRE EMB3D TID-115 para extração via interface física; Espressif ESP-IDF Security Guide para Secure Boot e Flash Encryption.
