# Preservação e análise do firmware

## Evidência disponível

- Origem: código fonte de laboratório criado para esta atividade (`src/main.cpp`).
- Formato: C++ para Arduino-ESP32; fonte legível, não imagem de firmware.
- Data da análise: 2026-11-06 (ambiente informado no contexto da sessão).
- Binário gerado: não. PlatformIO não estava disponível nesta sessão.
- Firmware original NexaSense: não fornecido.
- SHA-256 do fonte: ver `hashes.txt`.

## Revisão estática do fonte

Encontrados textos constantes de boot e depuração, o identificador fictício `LAB-NEXA-01`, a etiqueta `transport=MQTT` explicitamente identificada como exemplo e a formatação JSON dos valores lidos do DHT22. Não foram encontrados usuário, senha, chave ou token. Não há cliente Wi-Fi, HTTP ou MQTT; a string de transporte não representa comunicação de rede.

## Rastreabilidade

O manifesto calcula o hash do arquivo fonte presente no pacote. Quando um firmware autorizado for recebido, preserve cópia somente leitura, registre nome, tamanho, origem, data e SHA-256, e faça análise em cópia de trabalho. Não grave nem faça flash numa placa nesta etapa.
