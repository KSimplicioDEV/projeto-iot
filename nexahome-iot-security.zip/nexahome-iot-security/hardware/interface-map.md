# Mapa de interfaces físicas (simulação)

| Interface | Evidência no modelo | Função | Risco condicional | Verificação em placa real |
|---|---|---|---|---|
| GPIO 15 / fio do DHT22 | `diagram.json` | Leitura digital do sensor | Injeção/alteração de leitura se acesso físico permitir dirigir o sinal | Confirmar pino e proteção elétrica no esquemático |
| UART0 TX/RX | Console serial do firmware a 115200 | Log e diagnóstico | Dados de operação visíveis; bootloader/debug podem aumentar impacto se modos de gravação e controles estiverem acessíveis | Inspecionar pinout, resistores, pads, cabeçalho; observar console com autorização |
| JTAG | Não conectado nem evidenciado na simulação | Debug e possível acesso privilegiado | Extração/leitura/modificação se interface habilitada sem controle | Conferir revisão do ESP32, pads e configuração de produção; não inferir exposição apenas pela família |
| SPI/flash | Não inspecionado | Barramento do armazenamento externo em módulos aplicáveis | Leitura/alteração de firmware ou dados se acesso físico e proteções ausentes | Identificar encapsulamento e topologia; validar proteções sem dessoldagem destrutiva |
| Alimentação/reset/boot straps | Não modelado integralmente | Inicialização e modos de boot | Forçar modo de download/regravação se controle físico disponível e sem autenticação | Revisar esquema e testar somente unidade autorizada |

A simulação não reproduz depuração de silício, memória flash nem bloqueios eFuses. Nenhuma interface, exceto a saída serial do programa simulado, foi testada. Interface presente não equivale automaticamente a vulnerabilidade.
