# NexaSense | Avaliação didática de segurança IoT

## Objetivo e escopo

Projeto de laboratório simulado para praticar inventário de componentes e superfície de ataque num ESP32 com DHT22 e console serial. A extensão Wokwi para Cursor é usada para executar a simulação quando o projeto estiver compilado com PlatformIO. Não foram fornecidos placa NexaHome, firmware original, captura de rede ou arquivo de atualização. Por isso, resultados sobre hardware e tráfego reais não são alegados.

Todo o escopo é local e educacional. O firmware não conecta a Wi-Fi, broker MQTT, HTTP, serviço externo nem rede de produção; a menção MQTT na serial é texto ilustrativo. Não há credenciais reais.

## Arquitetura

```mermaid
flowchart LR
  DHT[DHT22 simulado] -->|GPIO 15, dado| MCU[ESP32 DevKit v1 simulado]
  MCU --> FLASH[Flash do módulo, não examinada]
  MCU --> UART[UART serial 115200: boot e telemetria demonstrativos]
  MCU -. futura versão .-> WIFI[Wi-Fi]
  WIFI -. fora desta simulação .-> BROKER[Broker local MQTT/TLS]
```

Imagem: `architecture/architecture-diagram.svg`.

## Ferramentas

- Cursor com extensão Wokwi Simulator (listada como instalada no Marketplace local).
- Wokwi, ESP32 DevKit v1, DHT22 e monitor serial.
- PlatformIO (compilação necessária antes de iniciar o simulador).
- SHA-256 (manifesto do código fonte deste exercício).

## Reproduzir no ambiente autorizado

1. Abra esta pasta no Cursor.
2. Tenha PlatformIO disponível para compilar o ambiente `esp32dev` (`platformio run`). O Wokwi não compila o firmware por conta própria.
3. Abra `diagram.json` para ver o circuito.
4. Use a paleta de comandos do Cursor: `Wokwi: Start Simulator` (ou o botão de execução da aba do diagrama).
5. Abra o monitor serial e observe `boot`, `device_id` e os eventos `telemetry` de laboratório.
6. Registre a saída como evidência local. A demonstração limita-se à exposição de dados operacionais pela interface serial simulada. Não há captura de MQTT porque não há MQTT no firmware.

O projeto foi aberto no Cursor e a extensão Wokwi identificou a configuração corrigida. A execução parou com o aviso “Missing Wokwi license key!”; além disso, PlatformIO não estava disponível para compilar o firmware. Nenhuma saída simulada foi registrada. Para concluir, configure a licença no Cursor e compile com PlatformIO antes de iniciar o simulador.

## Resumo preliminar

- Firmware: o código fonte didático imprime identificador de laboratório, mensagens de boot e valores ambientais na UART. O artefato binário original da NexaHome não foi entregue; partições, bibliotecas embarcadas em binário, endpoints e segredos do produto não foram analisados.
- Hardware: a simulação modela ESP32 e DHT22; GPIO 15 representa a conexão de dados do sensor. Pinos UART/JTAG são características plausíveis da família e precisam ser confirmados no módulo físico e na revisão específica de placa.
- Comunicação: somente saída UART local é produzida pelo programa. Wi-Fi/MQTT/TLS não foram exercitados nem inferidos.
- Achado demonstrado em código: a configuração didática deixa mensagens operacionais e telemetria disponíveis na serial. Isso é uma condição de exposição simulada; sua explorabilidade e impacto em NexaSense real não foram verificados.

## Arquivos

- `firmware/analysis-notes.md`: preservação, hash e limites da análise.
- `hardware/interface-map.md`: interfaces e perguntas de validação.
- `network/protocol-analysis.md`: protocolo observado e lacunas.
- `findings/findings.md`: evidências, risco e priorização.
- `remediation/hardening-plan.md`: medidas por fase.
- `video-script.md`: roteiro de gravação de até quatro minutos; não há vídeo gravado.
- `platformio.ini`, `wokwi.toml`, `diagram.json`, `src/main.cpp`: laboratório executável.

## Integridade

`firmware/hashes.txt` contém SHA-256 do código-fonte didático, não de um firmware de produto. Registre novo hash se alterar o código. Não publique segredos reais.

